﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AvaliacaoTecnica
{
    class Credito
    {
        public double ValorInicial { get; set; }
        public string Tipo { get; set; }
        public int Parcelas { get; set; }
        public DateTime PrimeiroVencimento { get; set; }
        public double Juros { get; set; }
        public double ValorTotal { get; set; }
        public string status { get; set; }


        public Credito(Double valor, string tipo, int parcelas, DateTime primeiroVencimento)
        {


                if (valor > 1000000.0)
                {
                    throw new ArgumentException("\nSeu Crédito não foi aprovado.\nValor inválido, o valor deve ser menor que R$ 1.000.000,00!");
                }

                if (parcelas < 5 || parcelas > 72)
                {
                    throw new ArgumentException("\nSeu Crédito não foi aprovado.\nNúmero de parcelas deve ser entre 5 e 72 vezes");
                }

                if (tipo == "Juridica" && valor < 15000.0)
                {
                    throw new ArgumentException("\nSeu Crédito não foi aprovado.\nValor para crédito de pessoa jurídica deve ser maior que R$ 15.000,00");
                }

                DateTime vencimentoMinimo = DateTime.Now.AddDays(15);
                DateTime vencimentoMaximo = DateTime.Now.AddDays(40);

                if (primeiroVencimento < vencimentoMinimo || primeiroVencimento > vencimentoMaximo)
                {
                    throw new ArgumentException($"\nSeu Crédito não foi aprovado.\nO primeiro vencimento deve estar entre {vencimentoMinimo} e {vencimentoMaximo}.");
                }


                this.ValorInicial = valor;
                this.Tipo = tipo;
                this.Parcelas = parcelas;
                this.PrimeiroVencimento = primeiroVencimento;

                switch (this.Tipo)
                {
                    case "Direto":
                        this.Juros = 0.02;
                        break;

                    case "Consignado":
                        this.Juros = 0.01;
                        break;

                    case "Juridica":
                        this.Juros = 0.05;
                        break;

                    case "Fisica":
                        this.Juros = 0.03;
                        break;

                    case "Imobiliario":
                        this.Juros = 0.09;
                        break;
                }

                this.status = "Aprovado";
            }

        public double CalculaJuros(Credito credito)
        {
            
            return ValorInicial * Juros;
        }

        public double CalculaValorTotal(Credito credito)
        {
            ValorTotal = ValorInicial + ValorInicial * Juros;

            return ValorTotal;
        }
    }
}
