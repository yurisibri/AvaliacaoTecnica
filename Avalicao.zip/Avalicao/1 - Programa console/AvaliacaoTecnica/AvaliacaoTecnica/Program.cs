﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AvaliacaoTecnica
{
    class Program
    {
        static void Main(string[] args)
        {
            int creditoCerto = 0;

            try
            {

                Console.WriteLine("Digite o Valor do Crédito.");
                double valor = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("\nDigite o Tipo de Crédito.");
                Console.WriteLine("Tipos disponíveis: Direto, Consignado, Juridica, Fisica, Imobiliario");
                string tipoCredito = Console.ReadLine();

                while (creditoCerto == 0)
                {

                    if (tipoCredito == "Direto" ||
                        tipoCredito == "Consignado" ||
                        tipoCredito == "Juridica" ||
                        tipoCredito == "Fisica" ||
                        tipoCredito == "Imobiliario")
                    {

                        Console.WriteLine("\nDigite a quantidade de parcelas.");
                        int parcelas = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("\nDigite o primeiro vencimento.");
                        string vencimento = Console.ReadLine();

                        int dia = Convert.ToInt32(vencimento.Substring(0, 2));
                        int mes = Convert.ToInt32(vencimento.Substring(3, 2));
                        int ano = Convert.ToInt32(vencimento.Substring(6, 4));

                        DateTime primeiroVencimento = new DateTime(ano, mes, dia);


                        Credito credito = new Credito(valor, tipoCredito, parcelas, primeiroVencimento);


                        Console.WriteLine("\nSeu crédito foi aprovado!");
                        Console.WriteLine("O valor total com juros é:" + credito.CalculaValorTotal(credito));
                        Console.WriteLine("O valor dos juros é:" + credito.CalculaJuros(credito));
                        Console.ReadLine();
                        creditoCerto = 1;

                    }
                    else
                    {
                        Console.WriteLine("\nDigite o Tipo de Crédito.");
                        Console.WriteLine("Tipos disponíveis: Direto, Consignado, Juridica, Fisica, Imobiliario");
                        tipoCredito = Console.ReadLine();
                        creditoCerto = 0;
                    }
                }

            }
            catch (ArgumentException e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
            }

            catch (Exception e)
            {
                Console.WriteLine("\nPreencha os valores\n");
                Console.ReadLine();
            }
        }
    }
}
