
//1-------------------------------


select c.nome , count(p.idparcelas)as parcelas , count(p.datapagamento) pagas from clientes c 
    inner join financiamentos f ON(c.idcliente = f.idcliente) 
    inner join parcelas p ON(p.idfinanciamento = f.idfinanciamento) 
    
    group by c.nome
    
    having count(p.idparcelas) * 0.6 <= count(p.datapagamento);

//2-------------------------------	
	

select c.nome , p.datavencimento , p.datapagamento from clientes c 
    inner join financiamentos f ON(c.idcliente = f.idcliente) 
    inner join parcelas p ON(p.idfinanciamento = f.idfinanciamento) 
    where p.datavencimento <= current_date - 5 and p.datapagamento is null and ROWNUM < 4
    ORDER BY c.nome;
    
	
//3-------------------------------	
	
	
select c.nome , count(p.idparcelas)as parcelas from clientes c 
    inner join financiamentos f ON(c.idcliente = f.idcliente) 
    inner join parcelas p ON(p.idfinanciamento = f.idfinanciamento) 
    
    where p.datapagamento > p.datavencimento
    
    group by c.nome
    
    having count(p.idparcelas) >= 2 ;
    
    
  
    